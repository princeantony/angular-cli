export class Home {     
  constructor() {
    this.message = 'Hello world';
  }
}