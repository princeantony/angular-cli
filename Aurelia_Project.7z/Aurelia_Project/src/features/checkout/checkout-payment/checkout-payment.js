export class CheckoutPayment {     
  constructor() {
    this.message = 'Hello world';
  }
}