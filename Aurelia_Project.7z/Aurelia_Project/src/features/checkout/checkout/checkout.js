export class Checkout {     
  constructor() {
    this.message = 'Hello world';
  }
}