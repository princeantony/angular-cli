import _ from 'lodash';
import {Product} from '../../models/product'
import {inject} from 'aurelia-framework';
import {HttpClient} from 'aurelia-fetch-client';
@inject(HttpClient)
export class UserService
{
    constructor(httpClient){
        this.httpClient = httpClient;
        this.userList = [];
    }
    getProducts()
    {
        this.httpClient.fetch('http://5afe6edfd0cc5b001479bf5b.mockapi.io/api/products')
        .then(response => response.json())
        .then(products=> { 
            return products.map(p=> {
                return new Product(p.name,p.id,p.description,p.imageUrl);
                });
            });
                      
    }
    
}