export class Catalog {     
  constructor() {
    this.message = 'Hello world - catalog';
  }
  configureRouter(config, router) {
    config.title = 'Catalog Page';
    config.map([
      {
        route: '', 
        name: 'products',
        moduleId: PLATFORM.moduleName('../product-list/product-list'),
        title:'Products' 
      },
      {
        route: 'details/:id', 
        name: 'product-details',
        moduleId: PLATFORM.moduleName('../product-details/product-details'),
        title:'Products' 
      }
      
    ]);
  }
}