export class ProductList {     
  constructor() {
    this.message = 'Hello world- Product';
  }
}