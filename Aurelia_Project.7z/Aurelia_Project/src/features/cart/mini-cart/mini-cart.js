export class MiniCart {     
  constructor() {
    this.message = 'Hello world';
  }
}