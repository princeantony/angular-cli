export class Cart {     
  constructor() {
    this.message = 'Hello world';
  }
}