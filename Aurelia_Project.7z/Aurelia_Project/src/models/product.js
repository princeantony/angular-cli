export class Product{
    constructor(name,id,description,imageUrl)
    {
        this.name = name;
        this.id = id;
        this.description = description;
        this.imageUrl = imageUrl;
    }
}