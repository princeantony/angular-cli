import _ from 'lodash';
import {inject} from 'aurelia-framework';
import {UserService} from './services/user-service';
@inject(UserService)
export class App2{
    constructor(userservice){
        this.users = [];
        userservice.getUsers().then(data =>  {this.users = data});
        this.search = "";
        this.userList = [];
        this.newUser = {name: "prince"}
    }
    getSerchResult(e)
    {
        //this.userList = this.users.filter( user=> user.login.startsWith(this.search)); 
        this.userList = _.filter(this.users, user=> user.login.startsWith(this.search)); 
    };
}
