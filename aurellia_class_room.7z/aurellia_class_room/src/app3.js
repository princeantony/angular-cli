import {PLATFORM} from 'aurelia-pal';
export class App3{
    constructor(){
    this.users = [{name:"Prince1", age:10},{name:"Prince2", age:20}]
    }
    configureRouter(config, router){
        this.router = router;
        config.titie = "User App";
        config.map([
            {
                route: '', name:'home', moduleId: PLATFORM.moduleName('./home/home'), title:'Home'
            },
            {
                route: 'about', name:'about', moduleId: PLATFORM.moduleName('./about/about'), title:'About'
            },
        ])
    }
    
}