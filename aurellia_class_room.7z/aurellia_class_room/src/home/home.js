export class Home {     
  constructor() {
    this.message = 'home page';
  }
}