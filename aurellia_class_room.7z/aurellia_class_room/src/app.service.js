import {inject} from 'aurelia-framework';
import {HttpClient} from 'aurelia-fetch-client';

@inject(HttpClient)
export class AppService
{
    constructor(http)
    {
        this.http = http;
    }
    users = [{name:"prince1", age:30}, {name:"prince2", age:35}];
    getUsers()
    {
        this.http.fetch('')
        return this.users;
    }
}