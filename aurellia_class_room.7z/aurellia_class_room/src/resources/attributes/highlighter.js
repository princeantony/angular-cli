import {inject} from 'aurelia-framework';

@inject(Element)
export class HighlighterCustomAttribute {
  constructor(element) {
    this.element = element;
  }

  valueChanged(newValue, oldValue) {
    debugger;
    this.element.style.color = newValue;
  }
}

