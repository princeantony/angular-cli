export class JsonValueConverter {
  toView(value) {
    if(value)
    {
      return JSON.stringify(value);
    }
  }

  // fromView(value) {

  // }
}

