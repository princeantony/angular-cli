import _ from 'lodash';
import {inject} from 'aurelia-framework';
import {HttpClient} from 'aurelia-fetch-client';
//let httpClient = new HttpClient();
@inject(HttpClient)
export class UserService
{
    constructor(httpClient){
        this.httpClient = httpClient;
        this.userList = [];
       // this.getUsers().then(data =>  {this.userList = data});
    }
    getUsers()
    {
        return this.httpClient.fetch('https://api.github.com/users').then(response => response.json());
                      
    }
    getUser(login)
    {
        this.getUsers().then(data =>  {this.userList = data});
        return _.find(this.userList, function(o) { return o.login == login; });
                      
    }
}