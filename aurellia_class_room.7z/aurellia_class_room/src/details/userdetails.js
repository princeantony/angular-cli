import {inject} from 'aurelia-framework';
import {UserService} from 'services/user-service';
@inject(UserService)
export class Userdetails {     
  constructor(userservice) {
    this.userservice = userservice;
    this.message = 'This is the detailed page';
    this.user = [];
  }
  activate(params, routeConfig, navigationInstruction) {
    if(params.login != undefined)
    this.user = this.userservice.getUser(params.login);
  }
}