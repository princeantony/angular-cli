export class App1 {
  constructor() {
    this.message = 'Hello World!';
   }
  showDetails(user)
  {
    this.selectedUser = user;
  }
}
